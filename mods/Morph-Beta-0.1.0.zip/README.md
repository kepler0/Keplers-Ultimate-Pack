Morph
====================

Gameplay:

- Kill a mob to acquire it as morph.
- Hit HOME/END (defaults) to open the Morph Selection GUI.
- Hit ENTER/RETURN/LEFT CLICK to select a Morph.
- Hit ESCAPE/RIGHT CLICK to close the GUI.
- Hit DELETE/BACKSPACE to delete a Morph.

Config file for more options.
